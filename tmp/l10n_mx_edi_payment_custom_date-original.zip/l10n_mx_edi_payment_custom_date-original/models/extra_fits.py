# -*- coding: utf-8 -*-
# Coded by German Ponce Dominguez 
#     ▬▬▬▬▬.◙.▬▬▬▬▬  
#       ▂▄▄▓▄▄▂  
#    ◢◤█▀▀████▄▄▄▄▄▄ ◢◤  
#    █▄ █ █▄ ███▀▀▀▀▀▀▀ ╬  
#    ◥ █████ ◤  
#     ══╩══╩═  
#       ╬═╬  
#       ╬═╬ Dream big and start with something small!!!  
#       ╬═╬  
#       ╬═╬ You can do it!  
#       ╬═╬   Let's go...
#    ☻/ ╬═╬   
#   /▌  ╬═╬   
#   / \
# Cherman Seingalt - german.ponce@outlook.com


from odoo import _, api, fields, models, tools
from odoo.exceptions import UserError, ValidationError
from odoo.tools import float_round
from odoo.tools.float_utils import float_compare
import calendar

#### Gestión Zona Horaria ####

from datetime import datetime
from pytz import timezone
import pytz
import time
from datetime import timedelta

#### Gestión del Excel ####


import tempfile

import xlwt
from io import BytesIO
import base64

from itertools import zip_longest

import logging
_logger = logging.getLogger(__name__)

format_date = "%Y-%m-%d"


class AccountBankStatementCustomDateWizard(models.TransientModel):
    _name = 'account.bank.statement.custom.date.wizard'
    _description = 'Asistente Fecha Efectiva Pago'

    def _get_current_date_time(self):

        return str(fields.Datetime.now())[0:19]

    cfdi_custom_date = fields.Datetime('Fecha efectiva de Pago', default=_get_current_date_time, required=True)

    def write_custom_date(self):
        active_ids = self._context['active_ids']
        statement_obj = self.env['account.bank.statement.line']
        statement_br = statement_obj.browse(active_ids).write({'cfdi_custom_date': self.cfdi_custom_date})
        return True


class AccountBankStatementLine(models.Model):
    _inherit ='account.bank.statement.line'


    cfdi_custom_date = fields.Datetime('Fecha efectiva de Pago', copy=False)

    def action_l10n_mx_edi_force_generate_cfdi(self):
        if self.move_id and self.cfdi_custom_date:
            self.move_id.cfdi_custom_date = self.cfdi_custom_date
        res = super(AccountBankStatementLine, self).action_l10n_mx_edi_force_generate_cfdi()
        return res


class AccountMove(models.Model):
    _inherit ='account.move'

    cfdi_custom_date = fields.Datetime('Fecha efectiva de Pago', copy=False)


   #### Gestión Zona Horaria ####

    def _get_date_time_xml_tz(self):
        context = self._context
        res = {}
        dt_format = tools.DEFAULT_SERVER_DATETIME_FORMAT
        tz = self.env.user.tz
        if not tz:
            tz = 'Mexico/General'
        date_time_report_tz = ""
        for rec in self:
            htz_diff = rec._get_time_zone()
            date_time = str(rec.cfdi_custom_date) [0:19]if rec.cfdi_custom_date else datetime.now()
            custom_payment_date = time.strftime('%Y-%m-%d %H:%M:%S', time.strptime(str(date_time)[:19], '%Y-%m-%d %H:%M:%S'))
            custom_payment_date = datetime.strptime(custom_payment_date, '%Y-%m-%d %H:%M:%S') + timedelta(hours=htz_diff) or False
            custom_payment_date = str(custom_payment_date)
            date_time_report_tz = str(custom_payment_date)[0:19].replace(' ','T') if custom_payment_date else False
        return date_time_report_tz


    def _get_time_zone(self):

        userstz = self.env.user.tz
        if not userstz:
            userstz = 'Mexico/General'
        a = 0
        if userstz:
            hours = timezone(userstz)
            fmt = '%Y-%m-%d %H:%M:%S %Z%z'
            now = datetime.now()
            loc_dt = hours.localize(datetime(now.year, now.month, now.day,
                                             now.hour, now.minute, now.second))
            timezone_loc = (loc_dt.strftime(fmt))
            diff_timezone_original = timezone_loc[-5:-2]
            timezone_original = int(diff_timezone_original)
            s = str(datetime.now(pytz.timezone(userstz)))
            s = s[-6:-3]
            timezone_present = int(s)*-1
            a = timezone_original + ((
                timezone_present + timezone_original)*-1)
        return a
    
    ############################ 


    # -------------------------------------------------------------------------
    # CFDI Generation: Payments
    # -------------------------------------------------------------------------

    def _l10n_mx_edi_add_payment_cfdi_values(self, cfdi_values, pay_results):
        # EXTENDS 'l10n_mx_edi'
        self.ensure_one()
        super()._l10n_mx_edi_add_payment_cfdi_values(cfdi_values, pay_results=pay_results)
        if cfdi_values.get('errors'):
            return
        cfdi_values['record'] = self
        cfdi_payment_datetime = ""
        invoice_results = pay_results.get('invoice_results',[])
        for invoice_vals in invoice_results:
            payment = invoice_vals.get('payment', False)
            invoice = invoice_vals.get('invoice', False)
            if payment:
                cfdi_payment_datetime = payment._get_date_time_xml_tz()
            else:
                if invoice:
                    if invoice.custom_payment_date:
                        cfdi_payment_datetime = move._get_date_time_xml_tz()
        if cfdi_payment_datetime:
            cfdi_values['fecha_pago'] = cfdi_payment_datetime
        
        # if move.payment_id:
        #     if move.payment_id.cfdi_custom_date:
        #         cfdi_payment_datetime = move.payment_id._get_date_time_xml_tz()
        #         res['cfdi_payment_date'] = cfdi_payment_datetime
        # else:
        #     if move.cfdi_custom_date:

        #         cfdi_payment_datetime = move._get_date_time_xml_tz()
        #         res['cfdi_payment_date'] = cfdi_payment_datetime

        #         issued_address = move._get_l10n_mx_edi_issued_address()
        #         tz = move._l10n_mx_edi_get_cfdi_partner_timezone(issued_address)
        #         tz_force = self.env['ir.config_parameter'].sudo().get_param('l10n_mx_edi_tz_%s' % move.journal_id.id, default=None)
        #         if tz_force:
        #             tz = timezone(tz_force)

        #         cfdi_date = str(fields.Datetime.to_string(datetime.now(tz)))
        #         cfdi_date = str(cfdi_date)[0:19].replace(' ','T') if cfdi_date else ''
        #         if cfdi_date:
        #             res['cfdi_date'] = cfdi_date
        # # raise UserError("AQUI ")
        # return res


class AccountPayment(models.Model):
    _inherit ='account.payment'


    def _get_current_date_time(self):

        return str(fields.Datetime.now())[0:19]

    cfdi_custom_date = fields.Datetime('Fecha efectiva de Pago', copy=False)


   #### Gestión Zona Horaria ####

    def _get_date_time_xml_tz(self):
        context = self._context
        res = {}
        dt_format = tools.DEFAULT_SERVER_DATETIME_FORMAT
        tz = self.env.user.tz
        if not tz:
            tz = 'Mexico/General'
        date_time_report_tz = ""
        for rec in self:
            htz_diff = rec._get_time_zone()
            date_time = str(rec.cfdi_custom_date) [0:19]if rec.cfdi_custom_date else datetime.now()
            custom_payment_date = time.strftime('%Y-%m-%d %H:%M:%S', time.strptime(str(date_time)[:19], '%Y-%m-%d %H:%M:%S'))
            custom_payment_date = datetime.strptime(custom_payment_date, '%Y-%m-%d %H:%M:%S') + timedelta(hours=htz_diff) or False
            custom_payment_date = str(custom_payment_date)
            date_time_report_tz = str(custom_payment_date)[0:19].replace(' ','T') if custom_payment_date else False
        return date_time_report_tz


    def _get_time_zone(self):

        userstz = self.env.user.tz
        if not userstz:
            userstz = 'Mexico/General'
        a = 0
        if userstz:
            hours = timezone(userstz)
            fmt = '%Y-%m-%d %H:%M:%S %Z%z'
            now = datetime.now()
            loc_dt = hours.localize(datetime(now.year, now.month, now.day,
                                             now.hour, now.minute, now.second))
            timezone_loc = (loc_dt.strftime(fmt))
            diff_timezone_original = timezone_loc[-5:-2]
            timezone_original = int(diff_timezone_original)
            s = str(datetime.now(pytz.timezone(userstz)))
            s = s[-6:-3]
            timezone_present = int(s)*-1
            a = timezone_original + ((
                timezone_present + timezone_original)*-1)
        return a
    
    ############################ 

class AccountRegisterPayments(models.TransientModel):
    _inherit = "account.payment.register"

    cfdi_custom_date = fields.Datetime('Fecha efectiva de Pago', copy=False)

    def _create_payment_vals_from_wizard(self, batch_result):
        res = super()._create_payment_vals_from_wizard(batch_result)
        res["cfdi_custom_date"] = self.cfdi_custom_date if self.cfdi_custom_date else False
        return res

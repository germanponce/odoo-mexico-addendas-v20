# -*- encoding: utf-8 -*-
# Coded by German Ponce Dominguez
# Cherman Seingalt - german.ponce@outlook.com

from odoo import api, fields, models, _
from lxml import etree

import logging
_logger = logging.getLogger(__name__)

class AddendaSale(models.Model):
    """docstring for AddendaFields"""
    _inherit = 'sale.order'
    
    addenda_type = fields.Selection(
        selection_add=[('retailer', 'Complemento Detallista')],
        ondelete={'retailer': 'set default'},
    )

    l10n_mx_edi_retailer_status = fields.Selection(
        selection=[
            ('original', 'Original'),
            ('copy', 'Copy'),
            ('reemplaza', 'Reemplaza'),
            ('delete', 'Delete'),
        ],
        string="Estatus Detallista",
        copy=False,
    )

    l10n_mx_edi_retailer_delivery = fields.Char(
        string="Folio(s) de Remisión",
        copy=False,
        help="Número(s) emitido(s) por el receptor al recibir la mercancía, separados por coma.",
    )
    l10n_mx_edi_retailer_delivery_date = fields.Date(
        string="Fecha de Remisión",
        copy=False,
    )
    l10n_mx_edi_retailer_purchase_order_date = fields.Date(
        string="Fecha de Orden de Compra",
        copy=False,
    )
    l10n_mx_edi_retailer_purchase_order_name = fields.Char(
        string="No. de Orden de Compra",
        copy=False,
    )
    l10n_mx_edi_retailer_purchase_contact_name = fields.Char(
        string="Contacto de Compras",
        copy=False,
    )
    l10n_mx_edi_retailer_special_service_type = fields.Selection(
        selection=[
            ('off_invoice', 'Off Invoice'),
            ('bill_back', 'Bill Back'),
        ],
        string="Tipo de Descuento/Cargo",
        copy=False,
    )

    # === Datos de compañía que usa el Complemento Detallista ===
    # Se muestran (solo lectura) en la factura para que el usuario detecte de
    # un vistazo si faltan por configurar en la ficha de la compañía, sin
    # tener que ir a buscarlos.
    l10n_mx_edi_retailer_company_buyer_gln = fields.Char(
        related='company_id.l10n_mx_edi_retailer_buyer_gln',
        string="GLN del Comprador (Compañía)",
    )
    l10n_mx_edi_retailer_company_seller_gln = fields.Char(
        related='company_id.l10n_mx_edi_retailer_seller_gln',
        string="GLN del Vendedor (Compañía)",
    )
    l10n_mx_edi_retailer_company_seller_alt_id = fields.Char(
        related='company_id.l10n_mx_edi_retailer_seller_alternate_party_identification',
        string="Identificador Alterno del Vendedor (Compañía)",
    )
    l10n_mx_edi_retailer_company_ship_to_gln = fields.Char(
        related='company_id.l10n_mx_edi_retailer_ship_to_gln',
        string="GLN del Destino de Envío (Compañía)",
    )
    l10n_mx_edi_retailer_company_data_missing = fields.Boolean(
        string="Faltan datos de compañía (Detallista)",
        compute='_compute_l10n_mx_edi_retailer_company_data_missing',
    )

    @api.depends(
        'company_id.l10n_mx_edi_retailer_buyer_gln',
        'company_id.l10n_mx_edi_retailer_seller_gln',
        'company_id.l10n_mx_edi_retailer_seller_alternate_party_identification',
        'company_id.l10n_mx_edi_retailer_ship_to_gln',
    )
    def _compute_l10n_mx_edi_retailer_company_data_missing(self):
        for move in self:
            company = move.company_id
            move.l10n_mx_edi_retailer_company_data_missing = not all([
                company.l10n_mx_edi_retailer_buyer_gln,
                company.l10n_mx_edi_retailer_seller_gln,
                company.l10n_mx_edi_retailer_seller_alternate_party_identification,
                company.l10n_mx_edi_retailer_ship_to_gln,
            ])


    def action_open_retailer_company_config(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': "Configuración de Compañía",
            'res_model': 'res.company',
            'res_id': self.company_id.id,
            'view_mode': 'form',
            'target': 'current',
        }


class AddendaOrderLine(models.Model):
    _inherit = 'sale.order.line'
    
    addenda_type = fields.Selection(
        selection_add=[('retailer', 'Complemento Detallista')],
        ondelete={'retailer': 'set null'},
    )

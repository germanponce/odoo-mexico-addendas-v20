# -*- encoding: utf-8 -*-
# Coded by German Ponce Dominguez
# Cherman Seingalt - german.ponce@outlook.com

from odoo import api, fields, models, _
from lxml import etree

import logging
_logger = logging.getLogger(__name__)


class L10nMxEdiDocument(models.Model):
    _inherit = 'l10n_mx_edi.document'

    def _decode_cfdi_attachment(self, cfdi_data):
        res = super()._decode_cfdi_attachment(cfdi_data)
        cfdi_node_custom = res.get('cfdi_node')

        if cfdi_node_custom is None:
            return res

        namespaces = {'detallista': 'http://www.sat.gob.mx/detallista'}
        detallista_node = cfdi_node_custom.find(".//detallista:detallista", namespaces)

        if detallista_node is not None:
            # BUGFIX: se estaba eliminando "xmlns:donat" (copiado del módulo de
            # donaciones) en vez de "xmlns:detallista".
            detallista_node.attrib.pop("{http://www.w3.org/2001/XMLSchema-instance}schemaLocation", None)
            detallista_node.attrib.pop("xmlns:detallista", None)

        res['cfdi_node'] = cfdi_node_custom
        return res


class AccountMove(models.Model):
    _inherit = 'account.move'

    def get_retailer_complement_values(self):
        """ Calcula todos los valores que el complemento Detallista necesita.
        Se llama directamente desde el arch del `l10n_mx_edi.addenda`
        (t-xml-node="complemento"), ya que en Odoo 19 el render de
        complementos/addendas solo recibe la variable `record`.

        ADVERTENCIA: algunos de estos valores (rate, folio,
        total_tax_details_transferred/withholding, total_price_discount)
        antes los proveía genéricamente el módulo `l10n_mx_edi_extended`
        (dependencia de este módulo, no incluida al migrar). Aquí se
        reconstruyeron con el mismo criterio que usa el core de Odoo 19
        para separar traslados/retenciones (tax.amount < 0 = retención),
        pero DEBES verificarlos contra tu implementación real antes de
        usarlos en producción.
        """
        self.ensure_one()

        values = (self.x_complement_retailer_data or 6 * '|').split('|')

        document_type = 'E' if self.move_type == 'out_refund' else 'I'

        currency_name = 'MXN'
        if self.currency_id != self.company_id.currency_id:
            currency_name = self.currency_id.name
        currency_precision = self.currency_id.decimal_places

        # TODO verificar: tipo de cambio a exponer en <currency><rateOfChange>.
        # Se deja en 1.0 si la factura está en la moneda de la compañía.
        rate = 1.0
        if self.currency_id != self.company_id.currency_id:
            rate = self.currency_id._get_conversion_rate(
                self.currency_id, self.company_id.currency_id, self.company_id, self.invoice_date or fields.Date.today()
            )

        pay_term = self.invoice_payment_term_id
        payment_terms_event = 'DATE_OF_INVOICE' if self.invoice_date == self.invoice_date_due else 'EFFECTIVE_DATE'

        net_payment_terms_type = 'BASIC_NET'
        if pay_term and pay_term.line_ids and pay_term.line_ids[-1].option in ('last_day_current_month', 'last_day_following_month'):
            net_payment_terms_type = 'END_OF_MONTH'

        pay_term_period_days = 0
        if pay_term and self.invoice_date_due and self.invoice_date:
            pay_term_period_days = (self.invoice_date_due - self.invoice_date).days

        # Descuento total: diferencia entre el importe bruto de línea y su subtotal.
        total_price_discount = sum(
            (line.price_unit * line.quantity) - line.price_subtotal
            for line in self.invoice_line_ids.filtered(lambda l: not l.display_type)
        )
        percentage_discount = 0.0
        if total_price_discount and self.amount_untaxed:
            percentage_discount = (total_price_discount / self.amount_untaxed) * 100

        # Separación traslados / retenciones con el mismo criterio del core (tax.amount < 0 = retención).
        tax_lines = self.line_ids.filtered(lambda l: l.tax_line_id)
        withholding_lines = tax_lines.filtered(lambda l: l.tax_line_id.amount < 0)
        transferred_lines = tax_lines - withholding_lines
        total_tax_details_transferred = abs(sum(transferred_lines.mapped('balance')))
        total_tax_details_withholding = abs(sum(withholding_lines.mapped('balance')))

        # TODO verificar: qué folio corresponde aquí (ACE = Remisión). Se usa
        # record.name como valor por defecto.
        folio = self.name

        return {
            'values': values,
            'document_type': document_type,
            'currency_name': currency_name,
            'currency_precision': currency_precision,
            'rate': rate,
            'folio': folio,
            'paymentTermsEvent': payment_terms_event,
            'netPaymentTermsType': net_payment_terms_type,
            'pay_term_period_days': pay_term_period_days,
            'percentage_discount': percentage_discount,
            'total_price_discount': total_price_discount,
            'total_tax_details_transferred': total_tax_details_transferred,
            'total_tax_details_withholding': total_tax_details_withholding,
        }

from lxml import etree

from odoo.tests import tagged
from odoo.tests.common import Form
from odoo.addons.l10n_mx_edi.tests.common import TestMxEdiCommon


@tagged("post_install", "-at_install")
class TestL10nMxEdiInvoiceRetailer(TestMxEdiCommon):

    def test_invoice_retailer(self):
        """Basic invoice flow for an invoice with the Detallista complement"""
        with self.mx_external_setup(self.frozen_today):
            invoice = self._create_invoice()

            retailer_wizard = self.env['x_l10n_mx_edi.retailer.wizard'].with_context(
                default_x_invoice_id=invoice.id
            ).create({})
            retailer_wizard = Form(retailer_wizard)
            retailer_wizard.x_status = "original"
            retailer_wizard.x_purchase_order_date = self.frozen_today.date()
            retailer_wizard.x_purchase_contact_name = "Azure Interior"
            retailer_wizard.x_special_service_type = "off_invoice"
            retailer_wizard.x_delivery = "P00011"
            retailer_wizard.x_delivery_date = self.frozen_today.date()
            retailer_wizard = retailer_wizard.save()

            retailer_set_action = self.env.ref("l10n_mx_edi_retailer.set_wizard_l10n_mx_edi_retailer_values")
            retailer_set_action.with_context(active_id=retailer_wizard.id).run()

            self.assertTrue(invoice.x_complement_retailer_data)

            with self.with_mocked_pac_sign_success():
                invoice._l10n_mx_edi_cfdi_invoice_try_send()

            self.assertEqual(invoice.l10n_mx_edi_cfdi_state, 'sent')

            attachment = invoice.l10n_mx_edi_cfdi_attachment_id
            self.assertTrue(attachment)

            xml_root = etree.fromstring(attachment.raw)
            namespaces = {'detallista': 'http://www.sat.gob.mx/detallista'}
            complement_nodes = xml_root.findall('.//detallista:detallista', namespaces)
            self.assertTrue(complement_nodes, "Complemento Detallista no fue agregado correctamente")

    def test_invoice_retailer_incomplete(self):
        """Case without contact name"""
        with self.mx_external_setup(self.frozen_today):
            invoice = self._create_invoice()

            retailer_wizard = self.env['x_l10n_mx_edi.retailer.wizard'].with_context(
                default_x_invoice_id=invoice.id
            ).create({})
            retailer_wizard = Form(retailer_wizard)
            retailer_wizard.x_status = "original"
            retailer_wizard.x_purchase_order_date = self.frozen_today.date()
            retailer_wizard.x_special_service_type = "off_invoice"
            retailer_wizard.x_delivery = "P00011"
            retailer_wizard.x_delivery_date = self.frozen_today.date()
            retailer_wizard = retailer_wizard.save()

            retailer_set_action = self.env.ref("l10n_mx_edi_retailer.set_wizard_l10n_mx_edi_retailer_values")
            retailer_set_action.with_context(active_id=retailer_wizard.id).run()

            with self.with_mocked_pac_sign_success():
                invoice._l10n_mx_edi_cfdi_invoice_try_send()

            self.assertEqual(invoice.l10n_mx_edi_cfdi_state, 'sent')

            attachment = invoice.l10n_mx_edi_cfdi_attachment_id
            xml_root = etree.fromstring(attachment.raw)
            namespaces = {'detallista': 'http://www.sat.gob.mx/detallista'}
            complement_nodes = xml_root.findall('.//detallista:detallista', namespaces)
            self.assertTrue(complement_nodes, "Complemento Detallista no fue agregado correctamente")

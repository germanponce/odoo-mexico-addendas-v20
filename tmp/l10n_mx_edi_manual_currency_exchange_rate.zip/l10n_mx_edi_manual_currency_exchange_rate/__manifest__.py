# -*- coding: utf-8 -*-

{
    "name" : "Tipo de Cambio Manual en Odoo",
    "version" : "1.7",
    "depends" : [   
                    'base',
                    'account',
                    'stock_account',
                    'l10n_mx_edi',
                    'l10n_mx_edi_extended', # Si no usa Comercio Exterior quitarla
                    ],
    "author": "German Ponce Dominguez",
    "summary": "",
    "description": """

    Tipo de Cambio Manual en Odoo 15 Integrado con la LdM
    """,
    "price": 150,    
    "currency": "EUR",
    'category': 'Accounting',
    "website" : "https://poncesoft.blogpost.com",
    "data" :[
             "views/account_invoice.xml",
             # "views/account_payment_view.xml",
    ],
    'qweb':[
    ],
    "auto_install": False,
    "installable": True,
    "license": "OPL-1",
}

# -*- coding: utf-8 -*-

from functools import lru_cache

from odoo import fields, models,api,_
from odoo.exceptions import UserError
from odoo.exceptions import UserError, ValidationError

import logging
_logger = logging.getLogger(__name__)


# class AccountPartialReconcile(models.Model):
#     _inherit = "account.partial.reconcile"
    
#     def _add_exchange_difference_cash_basis_vals(self, exchange_diff_vals):
#         _logger.info("\n\n##################################################### ")
#         _logger.info("\n\n###### _add_exchange_difference_cash_basis_vals >>>>> ")
#         context = self._context
#         _logger.info("\n\n...... context: " % context)
#         res = super(AccountPartialReconcile, self)._add_exchange_difference_cash_basis_vals(exchange_diff_vals)
#         _logger.info("\n\n##################################################### ")
#         return res

class account_invoice_line(models.Model):
    _inherit = 'account.move.line'

    @api.model
    def _create_exchange_difference_move(self, exchange_diff_vals):
        _logger.info("\n\n##################################################### ")
        _logger.info("\n\n###### _create_exchange_difference_move >>>>> ")
        context = self._context
        _logger.info("\n\n...... self: %s" % self)
        _logger.info("\n\n...... self.move_id: %s" % self.move_id)
        _logger.info("\n\n...... context: %s" % context)
        res = super(account_invoice_line, self)._create_exchange_difference_move(exchange_diff_vals)
        _logger.info("\n\n##################################################### ")
        return res

    # @api.model
    # def _add_exchange_difference_cash_basis_vals(self, exchange_diff_vals):
    #     _logger.info("\n\n##################################################### ")
    #     _logger.info("\n\n###### _add_exchange_difference_cash_basis_vals >>>>> ")
    #     context = self._context
    #     _logger.info("\n\n...... context: " % context)
    #     res = super(account_invoice_line, self)._add_exchange_difference_cash_basis_vals(exchange_diff_vals)
    #     _logger.info("\n\n##################################################### ")
    #     return res



    @api.depends('product_id', 'product_uom_id')
    def _compute_price_unit(self):
        # print ("##################################################### ")
        # print ("###### _compute_price_unit >>>>>>>>>>>>>>>>>>>>>>>>>> ")
        for line in self:
            # print ("...... line: ", line)
            # print ("...... line.move_id: ", line.move_id)
            exchange_rate_date = line.move_id.exchange_rate_date
            # print ("...... exchange_rate_date: ", exchange_rate_date)
            current_exchange_rate_by_date = line.move_id.current_exchange_rate_by_date
            current_exchange_rate_by_date_invert = line.move_id.current_exchange_rate_by_date_invert
            # print ("...... current_exchange_rate_by_date: ", current_exchange_rate_by_date)
            if not line.product_id or line.display_type in ('line_section', 'line_note'):
                continue
            if line.move_id.is_sale_document(include_receipts=True):
                document_type = 'sale'
            elif line.move_id.is_purchase_document(include_receipts=True):
                document_type = 'purchase'
            else:
                document_type = 'other'
            # print ("...... document_type: ", document_type)
            price_unit_f = line.product_id.with_context(exchange_rate_date=exchange_rate_date,current_exchange_rate_by_date=current_exchange_rate_by_date,current_exchange_rate_by_date_invert=current_exchange_rate_by_date_invert)._get_tax_included_unit_price(
                line.move_id.company_id,
                line.move_id.currency_id,
                line.move_id.date,
                document_type,
                fiscal_position=line.move_id.fiscal_position_id,
                product_uom=line.product_uom_id,
            )
            # print ("...... price_unit_f: ", price_unit_f)
            line.price_unit =  price_unit_f
        # print ("##################################################### ")

    @api.depends('currency_id', 'company_id', 'move_id.date', 
        'move_id.exchange_rate_date')
    def _compute_currency_rate(self):
        # print ("##################################################### ")
        # print ("###### _compute_currency_rate >>>>>>>>>>>>>>>>>>>>>>> ")
        @lru_cache()
        def get_rate(from_currency, to_currency, company, date):
            return self.env['res.currency']._get_conversion_rate(
                from_currency=from_currency,
                to_currency=to_currency,
                company=company,
                date=date,
            )
        for line in self:
            # print ("...... line.move_id.exchange_rate_date: ", line.move_id.exchange_rate_date)
            if line.move_id.exchange_rate_date:
                # current_exchange_rate_by_date = line.move_id.current_exchange_rate_by_date
                # current_exchange_rate_by_date = 1.0 / current_exchange_rate_by_date
                # line.currency_rate = current_exchange_rate_by_date or 1.0
                current_exchange_rate_by_date_invert = line.move_id.current_exchange_rate_by_date_invert
                line.currency_rate = current_exchange_rate_by_date_invert
            else:
                line.currency_rate = get_rate(
                    from_currency=line.company_currency_id,
                    to_currency=line.currency_id,
                    company=line.company_id,
                    date=line.move_id.date or fields.Date.context_today(line),
                )
        # print ("##################################################### ")

    # @api.model
    # def _prepare_reconciliation_single_partial(self, debit_vals, credit_vals, shadowed_aml_values=None):
    #     # print ("##################################################### ")
    #     # print ("###### _prepare_reconciliation_single_partial >>>>>>> ")

    #     """ Prepare the values to create an account.partial.reconcile later when reconciling the dictionaries passed
    #     as parameters, each one representing an account.move.line.
    #     :param debit_vals:  The values of account.move.line to consider for a debit line.
    #     :param credit_vals: The values of account.move.line to consider for a credit line.
    #     :return:            A dictionary:
    #         * debit_vals:   None if the line has nothing left to reconcile.
    #         * credit_vals:  None if the line has nothing left to reconcile.
    #         * partial_vals: The newly computed values for the partial.
    #     """

    #     _logger.info("\n\n##################################################### ")
    #     _logger.info("\n\n###### _prepare_reconciliation_single_partial >>>>> ")
    #     context = self._context
    #     _logger.info("\n\n...... self: %s" % self)
    #     _logger.info("\n\n...... context: %s" % context)
    #     _logger.info("\n\n...... debit_vals['record']: %s" % debit_vals.get('record',{}))
    #     _logger.info("\n\n...... credit_vals['record']: %s" % credit_vals.get('record',{}))
    #     ################ CHERMAN 2024 ####################
    #     if debit_vals['record'] and debit_vals['record'].move_id:
    #         _logger.info("\n\n...... debit_vals['record'].move_id: %s" % debit_vals['record'].move_id)
    #         _logger.info("\n\n...... revisamos la fecha del tipo de cambio ")
    #         if debit_vals['record'].move_id.exchange_rate_date:
    #             _logger.info("\n\n...... debit_vals['record'].move_id.exchange_rate_date: %s " % debit_vals['record'].move_id.exchange_rate_date)

    #     def get_odoo_rate(vals):
    #         _logger.info("\n\n.................................................")
    #         _logger.info("\n\n get_odoo_rate >>>>>>>>>>>>>>>>>>>>>>")
    #         # print ("...... get_odoo_rate >>>>>>>>>>>>>>>>>>>>>> ")
    #         # print ("...... vals: ", vals)
    #         # if vals.get('current_exchange_rate_by_date'):
    #         #     exchange_rate = vals.get('current_exchange_rate_by_date')
    #         #     return exchange_rate
    #         _logger.info("\n\n...... vals.get('current_exchange_rate_by_date_invert'): %s " % vals.get('current_exchange_rate_by_date_invert'))
    #         if vals.get('current_exchange_rate_by_date_invert'):
    #             _logger.info("\n\n 000000 >>>>>>>>>>>>>>>>>>>>>>")
    #             exchange_rate = vals.get('current_exchange_rate_by_date_invert')
    #             return exchange_rate
    #         if vals.get('record') and vals['record'].move_id.is_invoice(include_receipts=True):
    #             _logger.info("\n\n 11111 >>>>>>>>>>>>>>>>>>>>>>")
    #             exchange_rate_date = vals['record'].move_id.invoice_date
    #         else:
    #             _logger.info("\n\n 22222 >>>>>>>>>>>>>>>>>>>>>>")
    #             exchange_rate_date = vals['date']

    #         rate_f = recon_currency._get_conversion_rate(company_currency, recon_currency, vals['company'], exchange_rate_date)
    #         # print ("...... rate_f: ", rate_f)
    #         _logger.info("\n\n.................................................")
    #         return rate_f

    #     def get_accounting_rate(vals):
    #         # print ("...... get_accounting_rate >>>>>>>>>>>>>>>>>>>>>> ")
    #         # print ("...... company_currency.is_zero(vals['balance']): ", company_currency.is_zero(vals['balance']))
    #         # print ("......  vals['currency'].is_zero(vals['amount_currency']): ",  vals['currency'].is_zero(vals['amount_currency']))
    #         if company_currency.is_zero(vals['balance']) or vals['currency'].is_zero(vals['amount_currency']):
    #             return None
    #         else:
    #             return abs(vals['amount_currency']) / abs(vals['balance'])

    #     # ==== Determine the currency in which the reconciliation will be done ====
    #     # In this part, we retrieve the residual amounts, check if they are zero or not and determine in which
    #     # currency and at which rate the reconciliation will be done.

    #     res = {
    #         'debit_vals': debit_vals,
    #         'credit_vals': credit_vals,
    #     }

    #     # print ("...... debit_vals.get('record'): ", debit_vals.get('record'))
    #     # print ("...... debit_vals['record'].move_id: ", debit_vals['record'].move_id)
    #     # print ("...... debit_vals['record'].move_id.exchange_rate_date: ", debit_vals['record'].move_id.exchange_rate_date)
    #     # print ("...... debit_vals['record'].move_id.current_exchange_rate_by_date: ", debit_vals['record'].move_id.current_exchange_rate_by_date)
    #     # current_exchange_rate_by_date_invert

    #     # if debit_vals.get('record') and debit_vals['record'].move_id.exchange_rate_date and debit_vals['record'].move_id.current_exchange_rate_by_date:
    #     #     debit_vals['current_exchange_rate_by_date'] = debit_vals['record'].move_id.current_exchange_rate_by_date
    #     # if credit_vals.get('record') and credit_vals['record'].move_id.exchange_rate_date and credit_vals['record'].move_id.current_exchange_rate_by_date:
    #     #     credit_vals['current_exchange_rate_by_date'] = credit_vals['record'].move_id.current_exchange_rate_by_date

    #     if debit_vals.get('record') and debit_vals['record'].move_id.exchange_rate_date and debit_vals['record'].move_id.current_exchange_rate_by_date_invert:
    #         debit_vals['current_exchange_rate_by_date_invert'] = debit_vals['record'].move_id.current_exchange_rate_by_date_invert
    #     if credit_vals.get('record') and credit_vals['record'].move_id.exchange_rate_date and credit_vals['record'].move_id.current_exchange_rate_by_date_invert:
    #         credit_vals['current_exchange_rate_by_date_invert'] = credit_vals['record'].move_id.current_exchange_rate_by_date_invert
        
    #     remaining_debit_amount_curr = debit_vals['amount_residual_currency']
    #     remaining_credit_amount_curr = credit_vals['amount_residual_currency']
    #     remaining_debit_amount = debit_vals['amount_residual']
    #     remaining_credit_amount = credit_vals['amount_residual']

    #     company_currency = debit_vals['company'].currency_id
    #     has_debit_zero_residual = company_currency.is_zero(remaining_debit_amount)
    #     has_credit_zero_residual = company_currency.is_zero(remaining_credit_amount)
    #     has_debit_zero_residual_currency = debit_vals['currency'].is_zero(remaining_debit_amount_curr)
    #     has_credit_zero_residual_currency = credit_vals['currency'].is_zero(remaining_credit_amount_curr)
    #     is_rec_pay_account = debit_vals.get('record') \
    #                          and debit_vals['record'].account_type in ('asset_receivable', 'liability_payable')

    #     if debit_vals['currency'] == credit_vals['currency'] == company_currency \
    #             and not has_debit_zero_residual \
    #             and not has_credit_zero_residual:
    #         # Everything is expressed in company's currency and there is something left to reconcile.
    #         recon_currency = company_currency
    #         debit_rate = credit_rate = 1.0
    #         recon_debit_amount = remaining_debit_amount
    #         recon_credit_amount = -remaining_credit_amount
    #     elif debit_vals['currency'] == company_currency \
    #             and is_rec_pay_account \
    #             and not has_debit_zero_residual \
    #             and credit_vals['currency'] != company_currency \
    #             and not has_credit_zero_residual_currency:
    #         # The credit line is using a foreign currency but not the opposite line.
    #         # In that case, convert the amount in company currency to the foreign currency one.
    #         recon_currency = credit_vals['currency']
    #         debit_rate = get_odoo_rate(debit_vals)
    #         credit_rate = get_accounting_rate(credit_vals)
    #         recon_debit_amount = recon_currency.round(remaining_debit_amount * debit_rate)
    #         recon_credit_amount = -remaining_credit_amount_curr
    #     elif debit_vals['currency'] != company_currency \
    #             and is_rec_pay_account \
    #             and not has_debit_zero_residual_currency \
    #             and credit_vals['currency'] == company_currency \
    #             and not has_credit_zero_residual:
    #         # The debit line is using a foreign currency but not the opposite line.
    #         # In that case, convert the amount in company currency to the foreign currency one.
    #         recon_currency = debit_vals['currency']
    #         debit_rate = get_accounting_rate(debit_vals)
    #         credit_rate = get_odoo_rate(credit_vals)
    #         recon_debit_amount = remaining_debit_amount_curr
    #         recon_credit_amount = recon_currency.round(-remaining_credit_amount * credit_rate)
    #     elif debit_vals['currency'] == credit_vals['currency'] \
    #             and debit_vals['currency'] != company_currency \
    #             and not has_debit_zero_residual_currency \
    #             and not has_credit_zero_residual_currency:
    #         # Both lines are sharing the same foreign currency.
    #         recon_currency = debit_vals['currency']
    #         debit_rate = get_accounting_rate(debit_vals)
    #         credit_rate = get_accounting_rate(credit_vals)
    #         recon_debit_amount = remaining_debit_amount_curr
    #         recon_credit_amount = -remaining_credit_amount_curr
    #     elif debit_vals['currency'] == credit_vals['currency'] \
    #             and debit_vals['currency'] != company_currency \
    #             and (has_debit_zero_residual_currency or has_credit_zero_residual_currency):
    #         # Special case for exchange difference lines. In that case, both lines are sharing the same foreign
    #         # currency but at least one has no amount in foreign currency.
    #         # In that case, we don't want a rate for the opposite line because the exchange difference is supposed
    #         # to reduce only the amount in company currency but not the foreign one.
    #         recon_currency = company_currency
    #         debit_rate = None
    #         credit_rate = None
    #         recon_debit_amount = remaining_debit_amount
    #         recon_credit_amount = -remaining_credit_amount
    #     else:
    #         # Multiple involved foreign currencies. The reconciliation is done using the currency of the company.
    #         recon_currency = company_currency
    #         debit_rate = get_accounting_rate(debit_vals)
    #         credit_rate = get_accounting_rate(credit_vals)
    #         recon_debit_amount = remaining_debit_amount
    #         recon_credit_amount = -remaining_credit_amount

    #     # ==== Match both lines together and compute amounts to reconcile ====

    #     # Determine which line is fully matched by the other.
    #     compare_amounts = recon_currency.compare_amounts(recon_debit_amount, recon_credit_amount)
    #     min_recon_amount = min(recon_debit_amount, recon_credit_amount)
    #     debit_fully_matched = compare_amounts <= 0
    #     credit_fully_matched = compare_amounts >= 0

    #     # ==== Computation of partial amounts ====
    #     if recon_currency == company_currency:
    #         # Compute the partial amount expressed in company currency.
    #         partial_amount = min_recon_amount

    #         # Compute the partial amount expressed in foreign currency.
    #         if debit_rate:
    #             partial_debit_amount_currency = debit_vals['currency'].round(debit_rate * min_recon_amount)
    #             partial_debit_amount_currency = min(partial_debit_amount_currency, remaining_debit_amount_curr)
    #         else:
    #             partial_debit_amount_currency = 0.0
    #         if credit_rate:
    #             partial_credit_amount_currency = credit_vals['currency'].round(credit_rate * min_recon_amount)
    #             partial_credit_amount_currency = min(partial_credit_amount_currency, -remaining_credit_amount_curr)
    #         else:
    #             partial_credit_amount_currency = 0.0

    #     else:
    #         # recon_currency != company_currency
    #         # Compute the partial amount expressed in company currency.
    #         if debit_rate:
    #             partial_debit_amount = company_currency.round(min_recon_amount / debit_rate)
    #             partial_debit_amount = min(partial_debit_amount, remaining_debit_amount)
    #         else:
    #             partial_debit_amount = 0.0
    #         if credit_rate:
    #             partial_credit_amount = company_currency.round(min_recon_amount / credit_rate)
    #             partial_credit_amount = min(partial_credit_amount, -remaining_credit_amount)
    #         else:
    #             partial_credit_amount = 0.0
    #         partial_amount = min(partial_debit_amount, partial_credit_amount)

    #         # Compute the partial amount expressed in foreign currency.
    #         # Take care to handle the case when a line expressed in company currency is mimicking the foreign
    #         # currency of the opposite line.
    #         if debit_vals['currency'] == company_currency:
    #             partial_debit_amount_currency = partial_amount
    #         else:
    #             partial_debit_amount_currency = min_recon_amount
    #         if credit_vals['currency'] == company_currency:
    #             partial_credit_amount_currency = partial_amount
    #         else:
    #             partial_credit_amount_currency = min_recon_amount

    #     # Computation of the partial exchange difference. You can skip this part using the
    #     # `no_exchange_difference` context key (when reconciling an exchange difference for example).
    #     if not self._context.get('no_exchange_difference'):
    #         exchange_lines_to_fix = self.env['account.move.line']
    #         amounts_list = []
    #         if recon_currency == company_currency:
    #             if debit_fully_matched:
    #                 debit_exchange_amount = remaining_debit_amount_curr - partial_debit_amount_currency
    #                 if not debit_vals['currency'].is_zero(debit_exchange_amount):
    #                     if debit_vals.get('record'):
    #                         exchange_lines_to_fix += debit_vals['record']
    #                     amounts_list.append({'amount_residual_currency': debit_exchange_amount})
    #                     remaining_debit_amount_curr -= debit_exchange_amount
    #             if credit_fully_matched:
    #                 credit_exchange_amount = remaining_credit_amount_curr + partial_credit_amount_currency
    #                 if not credit_vals['currency'].is_zero(credit_exchange_amount):
    #                     if credit_vals.get('record'):
    #                         exchange_lines_to_fix += credit_vals['record']
    #                     amounts_list.append({'amount_residual_currency': credit_exchange_amount})
    #                     remaining_credit_amount_curr += credit_exchange_amount

    #         else:
    #             if debit_fully_matched:
    #                 # Create an exchange difference on the remaining amount expressed in company's currency.
    #                 debit_exchange_amount = remaining_debit_amount - partial_amount
    #                 if not company_currency.is_zero(debit_exchange_amount):
    #                     if debit_vals.get('record'):
    #                         exchange_lines_to_fix += debit_vals['record']
    #                     amounts_list.append({'amount_residual': debit_exchange_amount})
    #                     remaining_debit_amount -= debit_exchange_amount
    #                     if debit_vals['currency'] == company_currency:
    #                         remaining_debit_amount_curr -= debit_exchange_amount
    #             else:
    #                 # Create an exchange difference ensuring the rate between the residual amounts expressed in
    #                 # both foreign and company's currency is still consistent regarding the rate between
    #                 # 'amount_currency' & 'balance'.
    #                 debit_exchange_amount = partial_debit_amount - partial_amount
    #                 if company_currency.compare_amounts(debit_exchange_amount, 0.0) > 0:
    #                     if debit_vals.get('record'):
    #                         exchange_lines_to_fix += debit_vals['record']
    #                     amounts_list.append({'amount_residual': debit_exchange_amount})
    #                     remaining_debit_amount -= debit_exchange_amount
    #                     if debit_vals['currency'] == company_currency:
    #                         remaining_debit_amount_curr -= debit_exchange_amount

    #             if credit_fully_matched:
    #                 # Create an exchange difference on the remaining amount expressed in company's currency.
    #                 credit_exchange_amount = remaining_credit_amount + partial_amount
    #                 if not company_currency.is_zero(credit_exchange_amount):
    #                     if credit_vals.get('record'):
    #                         exchange_lines_to_fix += credit_vals['record']
    #                     amounts_list.append({'amount_residual': credit_exchange_amount})
    #                     remaining_credit_amount += credit_exchange_amount
    #                     if credit_vals['currency'] == company_currency:
    #                         remaining_credit_amount_curr -= credit_exchange_amount
    #             else:
    #                 # Create an exchange difference ensuring the rate between the residual amounts expressed in
    #                 # both foreign and company's currency is still consistent regarding the rate between
    #                 # 'amount_currency' & 'balance'.
    #                 credit_exchange_amount = partial_amount - partial_credit_amount
    #                 if company_currency.compare_amounts(credit_exchange_amount, 0.0) < 0:
    #                     if credit_vals.get('record'):
    #                         exchange_lines_to_fix += credit_vals['record']
    #                     amounts_list.append({'amount_residual': credit_exchange_amount})
    #                     remaining_credit_amount -= credit_exchange_amount
    #                     if credit_vals['currency'] == company_currency:
    #                         remaining_credit_amount_curr -= credit_exchange_amount

    #         if exchange_lines_to_fix:
    #             res['exchange_vals'] = exchange_lines_to_fix._prepare_exchange_difference_move_vals(
    #                 amounts_list,
    #                 exchange_date=max(debit_vals['date'], credit_vals['date']),
    #             )

    #     # ==== Create partials ====

    #     remaining_debit_amount -= partial_amount
    #     remaining_credit_amount += partial_amount
    #     remaining_debit_amount_curr -= partial_debit_amount_currency
    #     remaining_credit_amount_curr += partial_credit_amount_currency

    #     res['partial_vals'] = {
    #         'amount': partial_amount,
    #         'debit_amount_currency': partial_debit_amount_currency,
    #         'credit_amount_currency': partial_credit_amount_currency,
    #         'debit_move_id': debit_vals.get('record') and debit_vals['record'].id,
    #         'credit_move_id': credit_vals.get('record') and credit_vals['record'].id,
    #     }

    #     debit_vals['amount_residual'] = remaining_debit_amount
    #     debit_vals['amount_residual_currency'] = remaining_debit_amount_curr
    #     credit_vals['amount_residual'] = remaining_credit_amount
    #     credit_vals['amount_residual_currency'] = remaining_credit_amount_curr

    #     if recon_currency.is_zero(recon_debit_amount) or debit_fully_matched:
    #         res['debit_vals'] = None
    #     if recon_currency.is_zero(recon_credit_amount) or credit_fully_matched:
    #         res['credit_vals'] = None
    #     return res

    
class account_invoice(models.Model):
    _inherit ='account.move'
    
    @api.onchange('invoice_date','exchange_rate_date', 'move_type', 'currency_id', 'company_id')
    def _get_current_exchange_rate_by_date(self):
        for rec in self:
            current_exchange_rate_by_date = 1
            if rec.exchange_rate_date:
                inv_currency = rec.currency_id
                company_currency = rec.company_id.currency_id
                if company_currency != inv_currency:
                    date_ctx = rec.exchange_rate_date or rec.date or fields.Date.context_today(rec)
                    current_exchange_rate_by_date = inv_currency._convert(
                        1, company_currency, rec.company_id, rec.exchange_rate_date, round=False
                    )
            else:
                inv_currency = rec.currency_id
                company_currency = rec.company_id.currency_id
                if company_currency != inv_currency:
                    date_ctx = rec.date or fields.Date.context_today(rec)
                    current_exchange_rate_by_date = inv_currency._convert(
                        1, company_currency, rec.company_id, date_ctx, round=False
                    )

            rec.current_exchange_rate_by_date = current_exchange_rate_by_date

    @api.onchange('invoice_date', 'move_type', 'currency_id', 'company_id')
    def _is_company_currency_foreign(self):
        for rec in self:
            company_currency_foreign = False
            inv_currency = rec.currency_id
            company_currency = rec.company_id.currency_id
            if company_currency != inv_currency:
                company_currency_foreign = True
            rec.company_currency_foreign = company_currency_foreign

    @api.onchange('invoice_date','exchange_rate_date', 'move_type', 'currency_id', 'company_id')
    def _get_current_exchange_rate_by_date_invert(self):
        for rec in self:
            current_exchange_rate_by_date_invert = 1
            if rec.exchange_rate_date:
                inv_currency = rec.currency_id
                company_currency = rec.company_id.currency_id
                if company_currency != inv_currency:
                    date_ctx = rec.exchange_rate_date or rec.date or fields.Date.context_today(rec)

                    invoice_rates = inv_currency._get_rates(rec.company_id, date_ctx)
                    current_exchange_rate_by_date_invert = invoice_rates.get(inv_currency.id, 1.0)

            else:
                inv_currency = rec.currency_id
                company_currency = rec.company_id.currency_id
                if company_currency != inv_currency:
                    date_ctx = rec.date or fields.Date.context_today(rec)
                    invoice_rates = inv_currency._get_rates(rec.company_id, date_ctx)
                    current_exchange_rate_by_date_invert = invoice_rates.get(inv_currency.id, 1.0)

            rec.current_exchange_rate_by_date_invert = current_exchange_rate_by_date_invert

    company_currency_foreign = fields.Boolean('Moneda Extranjera', compute="_is_company_currency_foreign")
    current_exchange_rate_by_date = fields.Float('Tipo de Cambio', compute="_get_current_exchange_rate_by_date", digits=(14,4))
    current_exchange_rate_by_date_invert = fields.Float('Rate', compute="_get_current_exchange_rate_by_date_invert", digits=(14,14))
    exchange_rate_date = fields.Date(
        states={"posted": [("readonly", True)]},
        copy=False
    )

    def _compute_payments_widget_to_reconcile_info(self):
        for move in self:
            move.invoice_outstanding_credits_debits_widget = False
            move.invoice_has_outstanding = False

            if move.state != 'posted' \
                    or move.payment_state not in ('not_paid', 'partial') \
                    or not move.is_invoice(include_receipts=True):
                continue

            pay_term_lines = move.line_ids\
                .filtered(lambda line: line.account_id.account_type in ('asset_receivable', 'liability_payable'))

            domain = [
                ('account_id', 'in', pay_term_lines.account_id.ids),
                ('parent_state', '=', 'posted'),
                ('partner_id', '=', move.commercial_partner_id.id),
                ('reconciled', '=', False),
                '|', ('amount_residual', '!=', 0.0), ('amount_residual_currency', '!=', 0.0),
            ]

            payments_widget_vals = {'outstanding': True, 'content': [], 'move_id': move.id}

            if move.is_inbound():
                domain.append(('balance', '<', 0.0))
                payments_widget_vals['title'] = _('Outstanding credits')
            else:
                domain.append(('balance', '>', 0.0))
                payments_widget_vals['title'] = _('Outstanding debits')

            for line in self.env['account.move.line'].search(domain):

                if line.currency_id == move.currency_id:
                    # Same foreign currency.
                    amount = abs(line.amount_residual_currency)
                else:
                    # Different foreign currencies.
                    # current_exchange_rate_by_date_invert
                    # if move.exchange_rate_date and move.current_exchange_rate_by_date:
                    #     current_exchange_rate_by_date = 1.0 / move.current_exchange_rate_by_date
                    #     amount = abs(line.amount_residual) * current_exchange_rate_by_date
                    if move.exchange_rate_date and move.current_exchange_rate_by_date_invert:
                        current_exchange_rate_by_date_invert = move.current_exchange_rate_by_date_invert
                        amount = abs(line.amount_residual) * current_exchange_rate_by_date_invert
                    else:
                        amount = line.company_currency_id._convert(
                            abs(line.amount_residual),
                            move.currency_id,
                            move.company_id,
                            line.date,
                        )

                if move.currency_id.is_zero(amount):
                    continue

                payments_widget_vals['content'].append({
                    'journal_name': line.ref or line.move_id.name,
                    'amount': amount,
                    'currency_id': move.currency_id.id,
                    'id': line.id,
                    'move_id': line.move_id.id,
                    'date': fields.Date.to_string(line.date),
                    'account_payment_id': line.payment_id.id,
                })

            if not payments_widget_vals['content']:
                continue

            move.invoice_outstanding_credits_debits_widget = payments_widget_vals
            move.invoice_has_outstanding = True

    def action_post(self):
        no_exchange_difference = False
        for rec in self:
            if rec.company_currency_foreign and rec.current_exchange_rate_by_date_invert:
                no_exchange_difference = True
                for line in rec.invoice_line_ids:
                    prev_price = line.price_unit
                    line.price_unit = line.price_unit + 0.5
                    line.price_unit = prev_price
        ##### CHERMAN 2024 #####
        # Si tiene fecha de cambio modificada no genera movimiento de ajuste de tipos de cambio....
        if no_exchange_difference:
            res = super(account_invoice, self.with_context(no_exchange_difference=True)).action_post()   
        else:
            res = super(account_invoice, self).action_post()   
        ########################
        return res

class ProductProduct(models.Model):
    _inherit = "product.product"

    @api.model
    def _get_tax_included_unit_price(self, company, currency, document_date, document_type,
            is_refund_document=False, product_uom=None, product_currency=None,
            product_price_unit=None, product_taxes=None, fiscal_position=None
        ):
        """ Helper to get the price unit from different models.
            This is needed to compute the same unit price in different models (sale order, account move, etc.) with same parameters.
        """

        product = self

        assert document_type

        if product_uom is None:
            product_uom = product.uom_id
        if not product_currency:
            if document_type == 'sale':
                product_currency = product.currency_id
            elif document_type == 'purchase':
                product_currency = company.currency_id
        if product_price_unit is None:
            if document_type == 'sale':
                product_price_unit = product.with_company(company).lst_price
            elif document_type == 'purchase':
                product_price_unit = product.with_company(company).standard_price
            else:
                return 0.0
        if product_taxes is None:
            if document_type == 'sale':
                product_taxes = product.taxes_id.filtered(lambda x: x.company_id == company)
            elif document_type == 'purchase':
                product_taxes = product.supplier_taxes_id.filtered(lambda x: x.company_id == company)
        # Apply unit of measure.
        if product_uom and product.uom_id != product_uom:
            product_price_unit = product.uom_id._compute_price(product_price_unit, product_uom)
        # Apply fiscal position.
        if product_taxes and fiscal_position:
            product_taxes_after_fp = fiscal_position.map_tax(product_taxes)
            flattened_taxes_after_fp = product_taxes_after_fp._origin.flatten_taxes_hierarchy()
            flattened_taxes_before_fp = product_taxes._origin.flatten_taxes_hierarchy()
            taxes_before_included = all(tax.price_include for tax in flattened_taxes_before_fp)

            if set(product_taxes.ids) != set(product_taxes_after_fp.ids) and taxes_before_included:
                taxes_res = flattened_taxes_before_fp.compute_all(
                    product_price_unit,
                    quantity=1.0,
                    currency=currency,
                    product=product,
                    is_refund=is_refund_document,
                )
                product_price_unit = taxes_res['total_excluded']
                if any(tax.price_include for tax in flattened_taxes_after_fp):
                    taxes_res = flattened_taxes_after_fp.compute_all(
                        product_price_unit,
                        quantity=1.0,
                        currency=currency,
                        product=product,
                        is_refund=is_refund_document,
                        handle_price_include=False,
                    )
                    for tax_res in taxes_res['taxes']:
                        tax = self.env['account.tax'].browse(tax_res['id'])
                        if tax.price_include:
                            product_price_unit += tax_res['amount']

        exchange_rate_date = self._context.get('exchange_rate_date')
        # current_exchange_rate_by_date = self._context.get('current_exchange_rate_by_date')
        current_exchange_rate_by_date_invert = self._context.get('current_exchange_rate_by_date_invert')

        if currency != product_currency:
            if exchange_rate_date:
                # current_exchange_rate_by_date = 1.0 / current_exchange_rate_by_date
                # product_price_unit = product_price_unit * current_exchange_rate_by_date
                product_price_unit = product_price_unit * current_exchange_rate_by_date_invert
            else:
                product_price_unit = product_currency._convert(product_price_unit, currency, company, document_date)

        return product_price_unit

# class StockMove(models.Model):
#     _inherit = "stock.move"

#     def _get_price_unit(self):
#         """Take into account custom rate date, if provided"""
#         context = self._context
#         print ("############ CONTEXT: ", context)
#         res = super()._get_price_unit()
#         return res

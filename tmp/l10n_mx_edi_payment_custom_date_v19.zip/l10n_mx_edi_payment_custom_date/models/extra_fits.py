# -*- coding: utf-8 -*-
# Coded by German Ponce Dominguez
# Migrated to Odoo 19 - l10n_mx_edi CFDI 4.0 compatible

import logging

from pytz import timezone, UTC

from odoo import _, api, fields, models
from odoo.addons.l10n_mx_edi.models.l10n_mx_edi_document import CFDI_DATE_FORMAT

_logger = logging.getLogger(__name__)


class AccountPaymentCustomDateWizard(models.TransientModel):
    """Wizard to set the effective payment date (FechaPago) on one or
    more payments before (re)generating the CFDI payment complement."""

    _name = 'account.payment.custom.date.wizard'
    _description = 'Asistente – Fecha Efectiva de Pago CFDI'

    cfdi_custom_date = fields.Datetime(
        string='Fecha Efectiva de Pago',
        required=True,
        default=lambda self: fields.Datetime.now(),
        help="Fecha y hora que se usará como FechaPago en el XML del "
             "complemento de pago. Se convierte automáticamente a la "
             "zona horaria fiscal del domicilio emisor.",
    )

    def write_custom_date(self):
        """Write the custom payment date to the selected account.payment records."""
        active_ids = self._context.get('active_ids', [])
        if not active_ids:
            return True
        payments = self.env['account.payment'].browse(active_ids)
        # cfdi_custom_date is a writable related field on account.payment
        # that points to move_id.cfdi_custom_date (see AccountMove below).
        payments.move_id.write({'cfdi_custom_date': self.cfdi_custom_date})
        return {'type': 'ir.actions.act_window_close'}


# ---------------------------------------------------------------------------
# account.move – primary storage and CFDI injection
# ---------------------------------------------------------------------------

class AccountMove(models.Model):
    _inherit = 'account.move'

    cfdi_custom_date = fields.Datetime(
        string='Fecha Efectiva de Pago',
        copy=False,
        help="Si se establece, sobreescribe la FechaPago del XML del "
             "complemento de pago con esta fecha (convertida a la zona "
             "horaria fiscal del emisor). Déjelo vacío para usar la fecha "
             "contable del pago a las 12:00 horas (comportamiento estándar).",
    )

    # ------------------------------------------------------------------
    # CFDI Payment complement override
    # ------------------------------------------------------------------

    def _l10n_mx_edi_add_payment_cfdi_values(self, cfdi_values, pay_results):
        """Extend the base method to inject a custom FechaPago when set.

        EXTENDS 'l10n_mx_edi' (account.move._l10n_mx_edi_add_payment_cfdi_values)

        The parent sets:
            cfdi_values['fecha_pago'] = payment_date_at_noon.strftime(CFDI_DATE_FORMAT)

        We replace that value with cfdi_custom_date expressed in the fiscal
        timezone of the issued address (same convention used for 'fecha').
        """
        self.ensure_one()
        super()._l10n_mx_edi_add_payment_cfdi_values(cfdi_values, pay_results)

        # Bail out if the parent already detected errors.
        if cfdi_values.get('errors'):
            return

        if not self.cfdi_custom_date:
            return

        # --- Timezone conversion -------------------------------------------
        # cfdi_custom_date is stored as UTC (standard Odoo convention).
        # We need to express it in the fiscal timezone of the issued address
        # using the same helper already used for the 'fecha' attribute.
        issued_address = cfdi_values.get('issued_address')
        if issued_address:
            tz = issued_address._l10n_mx_edi_get_cfdi_timezone()
        else:
            # Fallback to Mexico central time if issued_address is unavailable.
            tz = timezone('America/Mexico_City')

        # self.cfdi_custom_date is a naive datetime stored as UTC in the DB.
        custom_dt_utc = self.cfdi_custom_date.replace(tzinfo=UTC)
        custom_dt_local = custom_dt_utc.astimezone(tz).replace(tzinfo=None)

        cfdi_values['fecha_pago'] = custom_dt_local.strftime(CFDI_DATE_FORMAT)
        _logger.debug(
            "AccountMove %s: overriding fecha_pago with %s (UTC %s → %s)",
            self.id, cfdi_values['fecha_pago'], self.cfdi_custom_date, tz,
        )


# ---------------------------------------------------------------------------
# account.payment – convenient access via related field
# ---------------------------------------------------------------------------

class AccountPayment(models.Model):
    _inherit = 'account.payment'

    # Expose cfdi_custom_date through the move_id relationship so that:
    #   • The field is editable directly on the payment form.
    #   • Values written here propagate automatically to account.move.
    #   • _create_payment_vals_from_wizard can include it in payment vals.
    cfdi_custom_date = fields.Datetime(
        related='move_id.cfdi_custom_date',
        string='Fecha Efectiva de Pago',
        readonly=False,
        copy=False,
        help="Fecha y hora que se usará como FechaPago en el complemento "
             "de pago del CFDI. Se convierte a la zona horaria fiscal del "
             "domicilio emisor al generar el XML.",
    )


# ---------------------------------------------------------------------------
# account.payment.register – capture date during batch payment registration
# ---------------------------------------------------------------------------

class AccountPaymentRegister(models.TransientModel):
    _inherit = 'account.payment.register'

    cfdi_custom_date = fields.Datetime(
        string='Fecha Efectiva de Pago',
        copy=False,
        help="Opcional. Si se establece, se usará como FechaPago en el "
             "complemento de pago del CFDI en lugar de la fecha contable "
             "del pago a las 12:00 horas.",
    )

    def _create_payment_vals_from_wizard(self, batch_result):
        """Propagate cfdi_custom_date to the payment values dict.

        EXTENDS 'account' (account.payment.register._create_payment_vals_from_wizard)
        """
        res = super()._create_payment_vals_from_wizard(batch_result)
        if self.cfdi_custom_date:
            # This key maps to account.payment.cfdi_custom_date (related field),
            # which in turn writes to account.move.cfdi_custom_date.
            res['cfdi_custom_date'] = self.cfdi_custom_date
        return res

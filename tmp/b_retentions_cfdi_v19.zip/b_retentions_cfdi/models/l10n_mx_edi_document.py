# -*- coding: utf-8 -*-
# Part of BIRTUM. See LICENSE file for full copyright and licensing details.
"""
Extensión de l10n_mx_edi.document para generar y timbrar CFDI de Retenciones
e Información de Pagos v1.0 (SAT México).

Flujo:
  1. _retention_cfdi_try_send(payment)
       → _build_retention_unsigned_xml(payment)    # Genera XML con QWeb
       → _retention_cadena_original(xml_node)       # Aplica XSLT del SAT
       → _retention_sign_sha1(cadena, certificate)  # Firma SHA-1
       → _retention_sign_using_finkok(xml_str, co.) # Timbra vía PAC Finkok
"""

import base64
import logging

from lxml import etree

from odoo import _, api, models, tools
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

# Ruta al XSLT de cadena original para Retenciones v1.0 (SAT).
# ⚠ El archivo debe obtenerse del SAT y colocarse en esta ruta dentro del módulo.
# Descarga: https://www.sat.gob.mx/cs/Satellite?blobcol=urldata&blobkey=id
#           &blobtable=MungoBlobs&blobwhere=1461173300266&ssbinary=true
CFDI_XSLT_RETENCIONES = 'b_retentions_cfdi/SAT/retenciones.xslt'

# URLs de Finkok para el servicio de Retenciones
FINKOK_RETENTIONS_TEST_URL = (
    'https://demo-facturacion.finkok.com/servicios/soap/retentions.wsdl'
)
FINKOK_RETENTIONS_PROD_URL = (
    'https://facturacion.finkok.com/servicios/soap/retentions.wsdl'
)


class L10nMxEdiDocument(models.Model):
    _inherit = 'l10n_mx_edi.document'

    # =========================================================================
    # Punto de entrada principal
    # =========================================================================

    @api.model
    def _retention_cfdi_try_send(self, payment):
        """Genera, firma y timbra el CFDI de Retenciones para el pago dado.

        Args:
            payment (account.payment): El pago con require_retention_cfdi=True.

        Returns:
            dict:
                - {'cfdi_str': str, 'uuid': str}  → éxito
                - {'error': str}                   → fallo
        """
        try:
            cfdi_values = payment._l10n_mx_edi_get_retention_cfdi_values()
        except UserError as e:
            return {'error': str(e)}

        # 1. Generar el XML sin sellar con QWeb
        try:
            unsigned_xml_bytes = self._build_retention_unsigned_xml(cfdi_values)
        except Exception as e:
            _logger.exception('Error generating retention XML')
            return {'error': _('Error generando el XML de Retención: %s', str(e))}

        # 2. Calcular cadena original y sellar con SHA-1
        try:
            xml_node = etree.fromstring(unsigned_xml_bytes)
            cadena = self._retention_cadena_original(xml_node)
            if not cadena:
                return {'error': _('No se pudo calcular la cadena original del CFDI de Retención.')}

            sello = self._retention_sign_sha1(cadena, cfdi_values['certificate'])
            xml_node.attrib['Sello'] = sello
        except Exception as e:
            _logger.exception('Error signing retention cadena')
            return {'error': _('Error al sellar el CFDI de Retención: %s', str(e))}

        # 3. Serializar y timbrar vía PAC
        sealed_xml_str = etree.tostring(
            xml_node, pretty_print=True, xml_declaration=True, encoding='UTF-8',
        ).decode('utf-8')

        result = self._retention_sign_using_finkok(sealed_xml_str, payment.company_id)
        return result

    # =========================================================================
    # Generación del XML sin timbrar
    # =========================================================================

    @api.model
    def _build_retention_unsigned_xml(self, cfdi_values):
        """Renderiza el template QWeb retentions_cfdi con los valores dados.

        Returns:
            bytes: XML sin sellar.
        """
        cfdi_str = self.env.ref('b_retentions_cfdi.retentions_cfdi')._render(cfdi_values)
        # cfdi_str puede ser bytes o str según versión de Odoo
        if isinstance(cfdi_str, str):
            cfdi_str = cfdi_str.encode('utf-8')

        # Sanear y validar como XML válido
        try:
            etree.fromstring(cfdi_str)
        except etree.XMLSyntaxError as e:
            _logger.error('Generated XML is not valid: %s\n%s', e, cfdi_str[:2000])
            raise
        return cfdi_str

    # =========================================================================
    # Cadena original (XSLT del SAT)
    # =========================================================================

    @api.model
    def _retention_cadena_original(self, xml_node):
        """Aplica el XSLT del SAT para obtener la cadena original.

        Args:
            xml_node: lxml.etree._Element — nodo raíz del CFDI de Retención.

        Returns:
            str: cadena original, o vacío si el XSLT no está disponible.

        Note:
            Si el archivo XSLT no está disponible, se usa una cadena vacía
            (útil en entorno de pruebas). En producción, el XSLT es obligatorio.
        """
        try:
            xslt_file = tools.file_open(CFDI_XSLT_RETENCIONES)
            cadena_root = etree.parse(xslt_file)
            transform = etree.XSLT(cadena_root)
            cadena = str(transform(xml_node))
            _logger.debug('Retention cadena original: %s', cadena[:120])
            return cadena
        except FileNotFoundError:
            _logger.warning(
                'XSLT de Retenciones no encontrado en %s. '
                'Descárgalo de sat.gob.mx y colócalo en la ruta indicada.',
                CFDI_XSLT_RETENCIONES,
            )
            # En test con PAC de prueba el sello no se valida → cadena vacía
            return ''
        except Exception as e:
            _logger.exception('Error applying retentions XSLT: %s', e)
            return ''

    # =========================================================================
    # Firma SHA-1 (requerida por esquema Retenciones v1.0 del SAT)
    # =========================================================================

    @api.model
    def _retention_sign_sha1(self, cadena, certificate):
        """Firma la cadena original con SHA-1 usando la llave privada del certificado.

        El esquema retenciones v1.0 del SAT requiere SHA-1 (no SHA-256).
        El esquema v2.0 usa SHA-256; si migras a v2.0, usa hashes.SHA256().

        Args:
            cadena (str): Cadena original generada por el XSLT.
            certificate (l10n_mx_edi.certificate): Certificado vigente.

        Returns:
            str: Sello en base64.
        """
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding as asym_padding

        # Obtener PEM de la llave privada
        # En Odoo 17-19, el método puede llamarse _get_pem_key o get_pem_key
        try:
            key_pem = certificate._get_pem_key(certificate.key, certificate.password)
        except AttributeError:
            try:
                key_pem = certificate.get_pem_key(certificate.key, certificate.password)
            except AttributeError as e:
                raise UserError(_(
                    'No se encontró el método de descifrado de llave en el '
                    'modelo l10n_mx_edi.certificate. Error: %s', str(e)
                ))

        if isinstance(key_pem, str):
            key_pem = key_pem.encode('utf-8')

        private_key = serialization.load_pem_private_key(key_pem, password=None)

        cadena_bytes = cadena.encode('utf-8')
        signature = private_key.sign(
            cadena_bytes,
            asym_padding.PKCS1v15(),
            hashes.SHA1(),  # ← Obligatorio para Retenciones v1.0
        )
        return base64.b64encode(signature).decode('utf-8')

    # =========================================================================
    # Timbrado vía PAC Finkok (WSDL de Retenciones)
    # =========================================================================

    @api.model
    def _retention_sign_using_finkok(self, xml_str, company):
        """Envía el CFDI de Retención al PAC Finkok para su timbrado.

        Usa el WSDL específico de retenciones, diferente al WSDL de facturas.

        Args:
            xml_str (str): XML sellado listo para timbrar.
            company (res.company): Compañía con configuración PAC.

        Returns:
            dict:
                - {'cfdi_str': str, 'uuid': str} → timbrado exitoso
                - {'error': str}                  → error del PAC
        """
        from odoo.tools.zeep import Client, Transport

        # Credenciales PAC
        if company.l10n_mx_edi_pac_test_env:
            sign_url = FINKOK_RETENTIONS_TEST_URL
            username = 'cfdi@vauxoo.com'
            password = 'vAux00__'
        else:
            sign_url = FINKOK_RETENTIONS_PROD_URL
            username = company.l10n_mx_edi_pac_username
            password = company.l10n_mx_edi_pac_password

        if not username or not password:
            return {'error': _(
                'Faltan credenciales PAC (usuario/contraseña) para la empresa %s.',
                company.name,
            )}

        _logger.info('Sending retention CFDI to Finkok (%s)', sign_url)

        try:
            transport = Transport(timeout=20, operation_timeout=20)
            client = Client(sign_url, transport=transport)

            response = client.service.sign(
                username=username,
                password=password,
                retencion=xml_str,
            )
        except Exception as e:
            _logger.exception('Finkok retentions SOAP error')
            return {'error': _('Error de comunicación con el PAC: %s', str(e))}

        # Parsear respuesta Finkok
        error_msgs = []

        # Incidencias (errores de negocio del PAC)
        if hasattr(response, 'Incidencias') and response.Incidencias:
            try:
                for inc in response.Incidencias.Incidencia:
                    msg = getattr(inc, 'MensajeIncidencia', str(inc))
                    error_msgs.append(str(msg))
            except Exception:
                error_msgs.append(str(response.Incidencias))

        if error_msgs:
            return {'error': '\n'.join(error_msgs)}

        # Documento timbrado
        signed_xml = getattr(response, 'Documento', None)
        if not signed_xml:
            return {'error': _('El PAC no devolvió el documento timbrado.')}

        # Extraer UUID del XML timbrado
        uuid = self._retention_extract_uuid(signed_xml)

        _logger.info('Retention CFDI stamped successfully. UUID: %s', uuid)
        return {'cfdi_str': signed_xml, 'uuid': uuid}

    # =========================================================================
    # Utilidades
    # =========================================================================

    @api.model
    def _retention_extract_uuid(self, signed_xml_str):
        """Extrae el UUID del TimbreFiscalDigital del XML timbrado."""
        try:
            if isinstance(signed_xml_str, str):
                signed_xml_str = signed_xml_str.encode('utf-8')
            root = etree.fromstring(signed_xml_str)
            tfd = root.find(
                './/{http://www.sat.gob.mx/TimbreFiscalDigital}TimbreFiscalDigital'
            )
            return tfd.get('UUID', '') if tfd is not None else ''
        except Exception as e:
            _logger.warning('Could not extract UUID from retention XML: %s', e)
            return ''
